<?PHP

print_r($_FILES['file']['name']);

print_r($_POST['input']);

?>